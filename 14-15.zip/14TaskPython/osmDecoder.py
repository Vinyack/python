import xml.etree.ElementTree as ET
from collections import defaultdict
import math

# Функция для вычисления расстояния между двумя координатами
def calculate_distance(lat1, lon1, lat2, lon2):
    return math.sqrt((lat1 - lat2) ** 2 + (lon1 - lon2) ** 2)

# Извлечение данных о скамейках и аптеках из OSM-файла
def extract_benches_and_pharmacies(file_path):
    tree = ET.parse(file_path)
    root = tree.getroot()
    benches = []
    pharmacies = []

    for node in root.findall("node"):
        lat = float(node.attrib.get("lat", 0))
        lon = float(node.attrib.get("lon", 0))
        tags = {tag.attrib['k']: tag.attrib['v'] for tag in node.findall("tag")}
        
        # Поиск скамеек
        if tags.get("amenity") == "bench":
            benches.append({
                "lat": lat,
                "lon": lon,
                "type": tags.get("bench:material", "Unknown"),
                "backrest": tags.get("backrest", "Unknown")
            })
        
        # Поиск аптек
        if tags.get("amenity") == "pharmacy":
            pharmacies.append({"lat": lat, "lon": lon})

    return benches, pharmacies

# Подсчёт статистики по скамейкам
def calculate_bench_statistics(benches, pharmacies, proximity_radius=0.0005):
    total_benches = len(benches)
    benches_by_type = defaultdict(int)
    benches_near_pharmacies = 0

    for bench in benches:
        bench_type = bench["type"]
        benches_by_type[bench_type] += 1

        # Проверяем, есть ли аптеки рядом
        for pharmacy in pharmacies:
            distance = calculate_distance(bench["lat"], bench["lon"], pharmacy["lat"], pharmacy["lon"])
            if distance <= proximity_radius:
                benches_near_pharmacies += 1
                break  # Достаточно найти одну аптеку

    return total_benches, benches_by_type, benches_near_pharmacies

# Загрузка данных из файлов
file1 = "12.osm"
file2 = "12 -2.osm"

benches1, pharmacies1 = extract_benches_and_pharmacies(file1)
benches2, pharmacies2 = extract_benches_and_pharmacies(file2)

# Объединяем данные
all_benches = benches1 + benches2
all_pharmacies = pharmacies1 + pharmacies2

# Вычисляем статистику
total_benches, benches_by_type, benches_near_pharmacies = calculate_bench_statistics(all_benches, all_pharmacies)

# Вывод статистики
print(f"Общее количество скамеек: {total_benches}")
print("Количество скамеек по типу:")
for bench_type, count in benches_by_type.items():
    print(f"  {bench_type}: {count}")
print(f"Количество скамеек рядом с аптеками: {benches_near_pharmacies}")
