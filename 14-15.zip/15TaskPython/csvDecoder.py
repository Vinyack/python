import csv
import re


# Function to read CSV file
def read_csv(file_path):
    with open(file_path, encoding='utf-8') as file:
        reader = csv.DictReader(file)
        data = [row for row in reader]
    return data


# Function to convert time string to seconds
def time_to_seconds(time_str):
    match_hours = re.match(r"(\d+) ч. (\d+) мин.", time_str)
    if match_hours:
        hours = int(match_hours[1])
        minutes = int(match_hours[2])
        return hours * 3600 + minutes * 60

    match_minutes_seconds = re.match(r"(\d+) мин. (\d+) сек.", time_str)
    if match_minutes_seconds:
        minutes = int(match_minutes_seconds[1])
        seconds = int(match_minutes_seconds[2])
        return minutes * 60 + seconds

    match_minutes_only = re.match(r"(\d+) мин.", time_str)
    if match_minutes_only:
        minutes = int(match_minutes_only[1])
        return minutes * 60

    return 0  # Return 0 if time format is not recognized


# Function to check if the test is passed
def test_passed(score):
    return float(score.replace(",", ".")) >= 6.0


# Function to filter participants
def filter_participants(data, start_letter, max_time_seconds):
    filtered = []
    for row in data:
        last_name = row["Фамилия"]
        time_spent = row["Затраченное время"]
        score = row["Оценка/10,00"]

        # Apply filtering conditions
        if (
            last_name.startswith(start_letter)
            and test_passed(score)
            and time_to_seconds(time_spent) < max_time_seconds
        ):
            filtered.append({
                "Last Name": last_name,
                "First Name": row["Имя"],
                "Email": row["Адрес электронной почты"],
                "Time Spent": time_spent,
                "Score": score
            })
    return filtered


# Function to analyze data and display results
def analyze_data(file_path, start_letter, max_time_seconds):
    data = read_csv(file_path)
    filtered_participants = filter_participants(data, start_letter, max_time_seconds)

    # Display results
    print(f"Number of participants with last names starting with '{start_letter}' who passed the test within the time limit: {len(filtered_participants)}")
    if filtered_participants:
        print("List of participants:")
        for participant in filtered_participants:
            print(
                f"{participant['Last Name']} {participant['First Name']} - "
                f"Email: {participant['Email']}, "
                f"Time: {participant['Time Spent']}, "
                f"Score: {participant['Score']}"
            )
    return filtered_participants


# Example usage
if __name__ == "__main__":
    file_path = "10 - 1.csv"  # Path to the CSV file
    start_letter = "К"  # Starting letter of last name
    max_time_seconds = 800  # Maximum time in seconds (e.g., 13 min 20 sec)

    analyze_data(file_path, start_letter, max_time_seconds)
